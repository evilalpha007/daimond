import React from "react";

export default function NoPageFound() {
  return <div>NoPageFound</div>;
}
