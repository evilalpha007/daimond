import React from "react";

export default function AdminGameReportScreen() {
  return <div>AdminGameReportScreen</div>;
}
