import React from "react";

export default function AdminChangePasswordScreen() {
  return <div>AdminChangePasswordScreen</div>;
}
