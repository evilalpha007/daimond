import React from "react";

export default function AdminMatchDetailsScreen() {
  return <div>AdminMatchDetailsScreen</div>;
}
