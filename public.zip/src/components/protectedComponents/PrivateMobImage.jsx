import React from "react";

const PrivateMobImage = () => {
  return <div>PrivateMobImage</div>;
};

export default PrivateMobImage;
