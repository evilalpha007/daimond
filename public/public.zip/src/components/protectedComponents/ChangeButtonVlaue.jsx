import React from "react";

const ChangeButtonVlaue = () => {
  return (
    <div>
      <div className="profit_loss_inner mt-1 mx-1 p-2 bg-[#0f2462] ">
        <h2 className="text-white text-2xl"> Change Button Values</h2>
      </div>
      <div className="flex"> 
      <div className="price_container flex flex-col p-4 ">
      <span>Price Label</span>
        <input type="text" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="text" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="text" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="text" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="text" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="text" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="text" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        
      </div>
      <div className="price_container flex flex-col p-4 ">
        <span>Price Label</span>
        <input type="number" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="number" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="number" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="number" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="number" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="number" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        <input type="number" className="p-2 w-[300px] mb-2 border-[#ccc]  border-[1px] text-[#555]" value="200" />
        
      </div>
      </div>
    </div>
  );
};

export default ChangeButtonVlaue;
