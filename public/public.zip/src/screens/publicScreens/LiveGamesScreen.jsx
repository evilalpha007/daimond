import React from "react";

export default function LiveGamesScreen() {
  return <div></div>;
}
