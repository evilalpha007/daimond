import React from "react";

const PrivateBasketBallScreen = () => {
  return <div>PrivateBasketBallScreen</div>;
};

export default PrivateBasketBallScreen;
