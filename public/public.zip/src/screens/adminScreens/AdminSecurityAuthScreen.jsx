import React from "react";

export default function AdminSecurityAuthScreen() {
  return <div>AdminSecurityAuthScreen</div>;
}
