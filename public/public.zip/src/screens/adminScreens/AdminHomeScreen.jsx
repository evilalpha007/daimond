import React from "react";
import AdminHeader from "../../components/adminComponents/Header/AdminHeader";

export default function AdminHomeScreen() {
  return <div>THis is home screen</div>;
}
