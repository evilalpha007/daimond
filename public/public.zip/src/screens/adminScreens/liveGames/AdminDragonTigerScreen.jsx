import React from "react";

export default function AdminDragonTigerScreen() {
  return (
    <div>
      {" "}
      <div className="card_inside_component p-[20px]">
        <div className="bg-[#312f40] p-[10px] font-bold text-white">
          <h2>AdminDragonTigerScreen</h2>
        </div>
      </div>
    </div>
  );
}
