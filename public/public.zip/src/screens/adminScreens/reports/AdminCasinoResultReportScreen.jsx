import React from "react";

export default function AdminCasinoResultReportScreen() {
  return <div>AdminCasinoResultReportScreen</div>;
}
