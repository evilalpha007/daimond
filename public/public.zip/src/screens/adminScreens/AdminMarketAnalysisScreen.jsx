import React from "react";

export default function AdminMarketAnalysisScreen() {
  return (
    <div>
      <h2>Market Analysis</h2>
      <p>You can view your cricket card books from sprt menu</p>
    </div>
  );
}
